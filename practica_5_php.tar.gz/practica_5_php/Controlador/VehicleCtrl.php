<?php

class VehicleCtrl
{
	private $model;


	function __construct()
	{
		require('models/vehicleMdl.php');
		$this->model = new vehicleMdl();
	}
	function run()
	{
		switch ($_GET['act']) {
			case 'value':
				$this->create();
				break;
			
			default:
				# code...
				break;
		}
	}

	private function create(){
		$vin = $this->ValidateNumber($_POST['vin']);
		$brand = $this->validateText($_POST['brand']);
		$type = validateText($_POST['type']);
		$model = ValidateNumber($_POST['model']);

		$result = $this->model->create($vin, $brand, $type, $model);

		//Insert succesful
		if($result)
		{
			//load the view
			require('views/vehicleInserted');
		}
		else
		{
			require('views/error');
		}

		/**
		*@param string $data
		*@return string $data
		*validate a string to be a number and clean it if number
		*/
	}
}