<?php

	echo $this->modelo->nombre; 
	print '<br/>';
	echo $this->modelo->email;
	print '<br/>';
	echo $this->modelo->telefono;
	print '<br/>';
	echo $this->modelo->direccion;

?>