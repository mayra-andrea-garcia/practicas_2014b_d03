<?php

	var_dump($this->modelo->datos);

?>