<?php

class ModeloUsuario
{

	public $datos;


	function listar($nombre,$email,$telefono,$direccion)
	{
		$this->datos = array('nombre'=>'$nombre',
						     'email'=>'$email',
						     'telefono'=>'$telefono',
						     'direccion'=>'$direccion');
		//$datos['nombre']= '$nombre';
		return $this->datos;
	}
}